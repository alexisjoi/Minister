# Minister

Minister is a voice-first, real-time Scripture remembrance companion. It helps believers recall, locate, and display Scripture while speaking, teaching, praying, coaching, singing, or ministering — listening to live speech and surfacing the verses behind the words.

## Run & Operate

- App runs via the `artifacts/minister: web` workflow (Vite dev server). Do not run `pnpm dev` at the repo root.
- `pnpm --filter @workspace/minister run typecheck` — typecheck the app (use this, not `build`, from the shell)
- `pnpm run typecheck` — full typecheck across all packages

## Stack

- Frontend-only MVP (no backend). React + Vite + TypeScript, built in the pnpm monorepo as artifact `minister` (previewPath `/`).
- Fonts: Playfair Display (display/serif) + Inter (body). Warm beige/brown/ivory palette — peaceful, reverent, readable from a distance.
- Search: `fuse.js` (fuzzy) blended with an IDF token scorer and a curated known-phrase index.
- Live transcription: browser Web Speech API (`webkitSpeechRecognition`).

## Where things live

- `src/data/kjv.json` — full public-domain KJV, flat array of `{ book, chapter, verse, text, translation: "KJV" }` (31,102 verses, ~6MB). Do not read directly; it is large. Source: api.getbible.net/v2/kjv.json.
- `src/services/scriptureSearchService.ts` — the Scripture search engine (source of truth for matching/ranking).
- `src/services/transcriptionService.ts` — Web Speech API wrapper for live mic transcription.
- `src/services/bibleApiService.ts`, `src/services/youVersionService.ts` — translation lookup / future NIV via YouVersion (placeholder; reads `VITE_YOUVERSION_APP_KEY`).
- `src/pages/` — `home`, `live` (Ministry View + Scripture Feed), `search`, `favorites`.
- `src/hooks/use-favorites.ts` — favorites persisted in `localStorage`.
- `src/lib/privacyNotice.ts` — privacy/legal notice copy.

## Architecture decisions

- **Hybrid search, not pure fuzzy.** Pure Fuse over-weights common words (e.g. "against us" beat the distinctive "weapon formed"). The engine blends Fuse fuzzy score + IDF-weighted token overlap, then layers a curated known-phrase index on top. See memory `scripture-search-engine.md`.
- **Curated known-phrase index** guarantees correct results for the well-known phrases ministers reach for — including modern paraphrases whose exact words are NOT in the KJV ("anxious"→KJV "careful", "hidden"→"hid", "door" not in Matthew 7:7). Lexical matching alone cannot resolve these; a future semantic/embedding layer is the long-term fix.
- **KJV only, stored locally** because it is public domain. NIV and other modern translations are copyrighted — they must come through proper licensing or authorized Bible APIs, never bundled. Legal notices reflect this.
- **Privacy:** the mic is never accessed until the user explicitly starts live listening.

## Product

- **Home** — entry point with calls to start Minister Live or search manually, plus the listening/privacy assurance.
- **Live** — starts mic transcription; detects trigger phrases ("God says", "the Bible says", ...) and streams matched verses into a real-time Scripture Feed, with a large Ministry View for the current verse.
- **Search** — manual phrase/concept/reference lookup.
- **Favorites** — saved verses (localStorage).

## User preferences

- Peaceful, reverent, ministry-ready design; warm and clean; readable from a distance.
- No emojis. No gimmicky graphics.

## Gotchas

- `src/data/kjv.json` is ~6MB — never `read`/`cat` it; query it programmatically if needed.
- When changing the search engine, re-verify the founder's demo phrases all rank #1 (see memory topic file for the test list and the Node verification snippet).
- Modern translations are copyrighted — never bundle NIV/ESV/etc. text; only KJV ships locally.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
