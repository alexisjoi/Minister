import { useFavorites } from "@/hooks/use-favorites";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Copy, BookmarkX } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Favorites() {
  const { favorites, removeFavorite } = useFavorites();
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The verse has been copied to your clipboard.",
    });
  };

  return (
    <div className="container mx-auto px-4 md:px-8 py-8 max-w-4xl">
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-serif font-bold text-primary">Saved Scripture</h1>
          <p className="text-muted-foreground">Verses you have saved from live listening or manual search.</p>
        </div>

        {favorites.length === 0 ? (
          <div className="text-center py-24 bg-muted/30 rounded-lg border border-border/50 border-dashed">
            <BookmarkX className="h-12 w-12 mx-auto mb-4 text-muted-foreground/30" />
            <h3 className="text-lg font-medium text-foreground mb-1">No favorites yet</h3>
            <p className="text-muted-foreground max-w-sm mx-auto">
              Verses you save during live listening or search will appear here for easy reference.
            </p>
          </div>
        ) : (
          <div className="grid gap-4">
            {favorites.map((fav, i) => {
              const v = fav.verse;
              const ref = `${v.book} ${v.chapter}:${v.verse}`;
              
              return (
                <Card key={fav.id} className="overflow-hidden border-border/50 bg-card/50 hover:bg-card transition-colors animate-in fade-in slide-in-from-bottom-4" style={{ animationDelay: `${(i % 10) * 50}ms` }} data-testid={`card-fav-${i}`}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-serif text-xl font-semibold text-primary">{ref}</h3>
                          <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-primary/10 text-primary">{v.translation}</span>
                          <span className="text-xs text-muted-foreground ml-2 capitalize bg-muted px-2 py-0.5 rounded-full">{fav.sourceMode}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => copyToClipboard(`${ref} ${v.translation} - ${v.text}`)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => removeFavorite(fav.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-lg leading-relaxed text-foreground font-serif">{v.text}</p>
                    <div className="mt-4 text-xs text-muted-foreground">
                      Saved on {new Date(fav.dateSaved).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
