import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Mic, Search, ShieldCheck } from "lucide-react";
import { PRIVACY_NOTICE_LIVE } from "@/lib/privacyNotice";

export default function Home() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 relative overflow-hidden">
      {/* Subtle background decoration */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center opacity-[0.03]">
        <div className="w-[800px] h-[800px] rounded-full border border-primary/20 scale-150" />
        <div className="w-[600px] h-[600px] rounded-full border border-primary/20 absolute" />
      </div>

      <div className="max-w-3xl mx-auto text-center space-y-8 z-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
        <div className="space-y-4">
          <h1 className="font-serif text-5xl md:text-7xl font-bold tracking-tight text-primary">
            Minister.
          </h1>
          <p className="text-xl md:text-2xl font-medium text-foreground/80 font-serif italic">
            A real-time Scripture remembrance companion.
          </p>
        </div>

        <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Minister helps believers recall, locate, and display Scripture while speaking, teaching, praying, coaching, singing, or ministering.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
          <Link href="/live">
            <Button size="lg" className="w-full sm:w-auto text-base gap-2 h-14 px-8" data-testid="button-start-live">
              <Mic className="w-5 h-5" />
              Start Minister Live
            </Button>
          </Link>
          <Link href="/search">
            <Button variant="outline" size="lg" className="w-full sm:w-auto text-base gap-2 h-14 px-8" data-testid="button-search-manual">
              <Search className="w-5 h-5" />
              Search Scripture Manually
            </Button>
          </Link>
        </div>

        <div className="pt-12 flex items-center justify-center gap-3 text-sm text-muted-foreground/80 max-w-md mx-auto text-left bg-muted/50 p-4 rounded-lg border border-border/50">
          <ShieldCheck className="w-8 h-8 shrink-0 text-primary/60" />
          <p>{PRIVACY_NOTICE_LIVE}</p>
        </div>
      </div>
    </div>
  );
}
