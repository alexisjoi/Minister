import { useState, useEffect, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search as SearchIcon, Copy, Bookmark, BookmarkCheck } from "lucide-react";
import { scriptureSearchService, SearchResult } from "@/services/scriptureSearchService";
import { MatchBadge } from "@/components/MatchBadge";
import { useFavorites } from "@/hooks/use-favorites";
import { useToast } from "@/hooks/use-toast";

export default function Search() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const { favorites, addFavorite, removeFavorite } = useFavorites();
  const { toast } = useToast();

  useEffect(() => {
    const handler = setTimeout(() => {
      if (query.trim().length >= 3) {
        const res = scriptureSearchService.search(query, { sensitivity: "High" });
        setResults(res);
      } else {
        setResults([]);
      }
    }, 300);
    return () => clearTimeout(handler);
  }, [query]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The verse has been copied to your clipboard.",
    });
  };

  return (
    <div className="container mx-auto px-4 md:px-8 py-8 max-w-4xl">
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-serif font-bold text-primary">Search Scripture</h1>
          <p className="text-muted-foreground">Find verses by phrase, concept, or reference.</p>
        </div>

        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="e.g. 'seek and ye shall find', 'perfect love casts out fear'"
            className="pl-12 h-14 text-lg bg-background shadow-sm border-primary/20 focus-visible:ring-primary"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            data-testid="input-search"
          />
        </div>

        <div className="space-y-4">
          {results.length > 0 ? (
            results.map((result, i) => {
              const v = result.verse;
              const ref = `${v.book} ${v.chapter}:${v.verse}`;
              const isFav = favorites.some(f => f.verse.book === v.book && f.verse.chapter === v.chapter && f.verse.verse === v.verse);
              
              return (
                <Card key={i} className="overflow-hidden border-border/50 bg-card/50 hover:bg-card transition-colors animate-in fade-in slide-in-from-bottom-4" style={{ animationDelay: `${i * 100}ms` }} data-testid={`card-result-${i}`}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start gap-4 mb-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-serif text-xl font-semibold text-primary">{ref}</h3>
                          <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-primary/10 text-primary">{v.translation}</span>
                          <MatchBadge matchType={result.matchType} />
                        </div>
                        {result.matchReason && <p className="text-xs text-muted-foreground italic">{result.matchReason}</p>}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => copyToClipboard(`${ref} ${v.translation} - ${v.text}`)} data-testid={`button-copy-${i}`}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className={`h-8 w-8 ${isFav ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`} onClick={() => isFav ? null : addFavorite(v, "manual")} disabled={isFav} data-testid={`button-save-${i}`}>
                          {isFav ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                    <p className="text-lg leading-relaxed text-foreground font-serif">{v.text}</p>
                  </CardContent>
                </Card>
              );
            })
          ) : query.length >= 3 ? (
            <div className="text-center py-12 text-muted-foreground bg-muted/30 rounded-lg border border-border/50 border-dashed">
              <SearchIcon className="h-8 w-8 mx-auto mb-3 opacity-20" />
              <p>No matches found for "{query}"</p>
              <p className="text-sm mt-1 opacity-70">Try using fewer words or a different phrase.</p>
            </div>
          ) : query.length > 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>Keep typing to search...</p>
            </div>
          ) : (
            <div className="text-center py-16 text-muted-foreground/60">
              <BookOpenIcon className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <p className="text-lg font-serif">The Word is a lamp unto thy feet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function BookOpenIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  );
}
