import { useState, useEffect, useRef, useCallback } from "react";
import { WebSpeechTranscriptionProvider } from "@/services/transcriptionService";
import {
  scriptureSearchService,
  SearchResult,
  Sensitivity,
  detectTrigger,
  detectSpeechContext,
  SpeechContext,
} from "@/services/scriptureSearchService";
import { useFavorites } from "@/hooks/use-favorites";
import { useLiveSettings } from "@/hooks/use-live-settings";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { MatchBadge } from "@/components/MatchBadge";
import { Mic, MicOff, Maximize2, Minimize2, Pause, Play, Trash2, Copy, Bookmark, BookmarkCheck, ShieldAlert, AlertCircle, Settings2, ChevronDown, Sparkles, Quote } from "lucide-react";
import { CONSENT_NOTICE, NIV_PLACEHOLDER_NOTICE } from "@/lib/privacyNotice";
import { useToast } from "@/hooks/use-toast";

type AppStatus = 'Not Listening' | 'Requesting Permission' | 'Listening' | 'Paused' | 'Error';

// A verse stays out of the feed for this long after being shown, so a slowly
// sliding transcript window does not surface the same Scripture over and over.
const REPEAT_COOLDOWN_MS = 45000;

// When a Scripture-quote cue or active ministry context is detected, search one
// step more permissively than the user's chosen sensitivity.
function bumpSensitivity(level: Sensitivity): Sensitivity {
  if (level === "Low") return "Medium";
  if (level === "Medium") return "High";
  return "High";
}

function sameVerse(a: SearchResult["verse"], b: SearchResult["verse"]) {
  return a.book === b.book && a.chapter === b.chapter && a.verse === b.verse;
}

export default function Live() {
  const [status, setStatus] = useState<AppStatus>('Not Listening');
  const [interimText, setInterimText] = useState("");
  const [finalText, setFinalText] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [hasConsented, setHasConsented] = useState(false);
  const [ministryView, setMinistryView] = useState(false);
  const [feed, setFeed] = useState<SearchResult[]>([]);
  const [detectionPaused, setDetectionPaused] = useState(false);
  const [translation, setTranslation] = useState<"KJV" | "NIV" | "Both">("KJV");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeTrigger, setActiveTrigger] = useState<string | null>(null);
  const [activeContext, setActiveContext] = useState<SpeechContext | null>(null);

  const { settings, update } = useLiveSettings();

  const providerRef = useRef<WebSpeechTranscriptionProvider | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const detectionPausedRef = useRef(false);

  // Rolling transcript state, held in refs so the (once-registered) provider
  // callbacks always read the latest values without stale closures.
  const committedWordsRef = useRef<string[]>([]);
  const interimRef = useRef("");
  const lastWindowRef = useRef("");
  const shownRefsRef = useRef<Map<string, number>>(new Map());
  const settingsRef = useRef(settings);

  const { favorites, addFavorite } = useFavorites();
  const { toast } = useToast();

  useEffect(() => {
    detectionPausedRef.current = detectionPaused;
  }, [detectionPaused]);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // Run Scripture detection on the rolling transcript window (after debounce).
  const runDetection = useCallback(() => {
    if (detectionPausedRef.current) return;

    const { windowSize, sensitivity, triggerMode, voiceCoachMode } = settingsRef.current;

    // Rolling window: only the last `windowSize` spoken words (committed + the
    // current interim phrase) are searched.
    const interimWords = interimRef.current.split(/\s+/).filter(Boolean);
    const allWords = [...committedWordsRef.current, ...interimWords];
    const recentWords = allWords.slice(-windowSize).join(" ").trim();

    if (recentWords.length < 4) return;
    // Skip if the window has not meaningfully changed since the last search.
    if (recentWords === lastWindowRef.current) return;
    lastWindowRef.current = recentWords;

    // Scripture Trigger Mode: a quotation cue anywhere in the window.
    const trigger = triggerMode ? detectTrigger(recentWords) : null;
    // Voice Coach Companion Mode: recognize ministry/teaching/prayer patterns.
    const context = voiceCoachMode ? detectSpeechContext(recentWords) : null;
    setActiveTrigger(trigger);
    setActiveContext(context);

    // Lean in (search more permissively) when actively quoting or ministering.
    const aggressive = (triggerMode && !!trigger) || (voiceCoachMode && !!context);
    const effectiveSensitivity = aggressive ? bumpSensitivity(sensitivity) : sensitivity;

    // Strip the quotation cue (which may appear mid-sentence) so its common words
    // don't dilute the lexical score of the Scripture that follows it.
    let query = recentWords;
    if (trigger) {
      const escaped = trigger.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const stripped = recentWords.replace(new RegExp(escaped, "ig"), " ").replace(/\s+/g, " ").trim();
      if (stripped.length >= 4) query = stripped;
    }

    const results = scriptureSearchService.search(query, {
      sensitivity: effectiveSensitivity,
    });
    if (results.length === 0) return;

    const topMatch = results[0];
    const refKey = `${topMatch.verse.book} ${topMatch.verse.chapter}:${topMatch.verse.verse}`;
    const now = Date.now();
    const lastShown = shownRefsRef.current.get(refKey);

    // Reduce repeats: respect a per-verse cooldown.
    if (lastShown && now - lastShown < REPEAT_COOLDOWN_MS) return;
    shownRefsRef.current.set(refKey, now);

    setFeed((prev) => {
      if (prev[0] && sameVerse(prev[0].verse, topMatch.verse)) return prev;
      return [topMatch, ...prev].slice(0, 50);
    });
  }, []);

  // Debounce transcription updates so we don't run a search on every interim
  // callback — only after speech briefly settles (350ms).
  const scheduleDetection = useCallback(() => {
    if (detectionPausedRef.current) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runDetection(), 350);
  }, [runDetection]);

  // Initialize provider (once).
  useEffect(() => {
    const provider = new WebSpeechTranscriptionProvider();

    provider.onStatusChange((newStatus) => setStatus(newStatus));
    provider.onError((err) => setErrorMsg(err));

    provider.onInterimResult((text) => {
      interimRef.current = text;
      setInterimText(text);
      scheduleDetection();
    });

    provider.onFinalResult((text) => {
      const words = text.split(/\s+/).filter(Boolean);
      committedWordsRef.current.push(...words);
      interimRef.current = "";
      setFinalText((prev) => (prev ? prev + " " : "") + text.trim());
      setInterimText("");
      scheduleDetection();
    });

    providerRef.current = provider;

    return () => {
      provider.stop();
    };
  }, [scheduleDetection]);

  // Clean up any pending debounce on unmount.
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current && !ministryView) {
      scrollRef.current.scrollTop = 0; // Feed is latest first
    }
  }, [feed, ministryView]);

  const toggleListen = () => {
    if (status === 'Listening') {
      providerRef.current?.stop();
    } else {
      if (!hasConsented) setHasConsented(true);
      setErrorMsg("");
      providerRef.current?.start();
    }
  };

  const clearTranscript = () => {
    setFinalText("");
    setInterimText("");
    committedWordsRef.current = [];
    interimRef.current = "";
    lastWindowRef.current = "";
    setActiveTrigger(null);
    setActiveContext(null);
  };

  const clearFeed = () => {
    setFeed([]);
    shownRefsRef.current.clear();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  // Ministry View (full-bleed focus on the current match — readable across a room).
  if (ministryView && feed.length > 0) {
    const topMatch = feed[0];
    const v = topMatch.verse;
    const ref = `${v.book} ${v.chapter}:${v.verse}`;

    return (
      <div className="fixed inset-0 z-50 bg-background text-foreground p-6 md:p-12 flex flex-col items-center justify-center animate-in fade-in zoom-in-95 duration-300">
        <Button variant="ghost" size="lg" className="absolute top-6 right-6 md:top-8 md:right-8 text-lg" onClick={() => setMinistryView(false)} data-testid="button-close-ministry-view">
          <Minimize2 className="h-6 w-6 mr-2" />
          Exit View
        </Button>

        <div className="max-w-7xl w-full text-center space-y-10 md:space-y-14">
          <div className="flex flex-col items-center gap-5">
            <h2 className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-serif font-bold text-primary tracking-tight leading-none">
              {ref}
            </h2>
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center px-4 py-1.5 rounded-full bg-primary/10 text-primary text-lg md:text-2xl font-medium">
                {v.translation}
              </span>
              <MatchBadge matchType={topMatch.matchType} className="text-base md:text-xl px-3 py-1" />
            </div>
          </div>
          <p className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-snug font-serif text-foreground">
            &ldquo;{v.text}&rdquo;
          </p>
        </div>

        <div className="absolute bottom-6 left-6 right-6 md:bottom-8 md:left-8 md:right-8 flex justify-between items-end opacity-60 hover:opacity-100 transition-opacity">
          <div className="text-base md:text-lg font-medium flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${status === 'Listening' ? 'bg-red-500 animate-pulse' : 'bg-muted-foreground'}`} />
            {status}
          </div>
          {activeContext && (
            <div className="text-base md:text-lg font-medium flex items-center gap-2 text-primary">
              <Sparkles className="h-5 w-5" />
              {activeContext}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col md:flex-row h-[calc(100vh-4rem-5rem)] overflow-hidden">
      {/* LEFT: Transcript & Controls */}
      <div className="w-full md:w-1/3 border-r border-border/50 bg-muted/10 flex flex-col p-6 gap-5 overflow-auto">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-serif font-semibold text-primary">Live Session</h2>
            <div className="flex items-center gap-2 text-sm font-medium px-3 py-1 bg-background rounded-full border border-border">
              <div className={`w-2 h-2 rounded-full ${status === 'Listening' ? 'bg-red-500 animate-pulse' : status === 'Error' ? 'bg-destructive' : 'bg-muted-foreground'}`} />
              {status}
            </div>
          </div>

          {!hasConsented && status === 'Not Listening' && (
            <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg text-sm text-primary/80 mb-2">
              <ShieldAlert className="h-5 w-5 mb-2" />
              {CONSENT_NOTICE}
            </div>
          )}

          {errorMsg && (
            <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-sm text-destructive flex items-start gap-2">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <p>{errorMsg}</p>
            </div>
          )}

          <Button
            size="lg"
            className={`w-full h-14 text-lg gap-2 transition-all ${status === 'Listening' ? 'bg-destructive hover:bg-destructive/90 text-white' : ''}`}
            onClick={toggleListen}
            data-testid="button-toggle-listen"
          >
            {status === 'Listening' ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            {status === 'Listening' ? 'Stop Listening' : 'Start Listening'}
          </Button>

          {status === 'Listening' && (
            <Button variant="outline" className="w-full gap-2" onClick={() => setDetectionPaused(!detectionPaused)} data-testid="button-toggle-detection">
              {detectionPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              {detectionPaused ? 'Resume Detection' : 'Pause Detection'}
            </Button>
          )}
        </div>

        {/* Settings */}
        <Collapsible open={settingsOpen} onOpenChange={setSettingsOpen} className="rounded-lg border border-border/50 bg-background">
          <CollapsibleTrigger asChild>
            <button className="w-full flex items-center justify-between p-3 text-sm font-medium text-foreground/80 hover:text-primary transition-colors" data-testid="button-settings">
              <span className="flex items-center gap-2">
                <Settings2 className="h-4 w-4" />
                Listening Settings
              </span>
              <ChevronDown className={`h-4 w-4 transition-transform ${settingsOpen ? 'rotate-180' : ''}`} />
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="px-4 pb-4 pt-1 space-y-5">
            {/* Sensitivity */}
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Search Sensitivity</Label>
              <ToggleGroup
                type="single"
                value={settings.sensitivity}
                onValueChange={(v) => v && update("sensitivity", v as Sensitivity)}
                className="grid grid-cols-3 gap-1"
              >
                {(["Low", "Medium", "High"] as Sensitivity[]).map((s) => (
                  <ToggleGroupItem key={s} value={s} className="text-xs h-8 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground" data-testid={`sensitivity-${s.toLowerCase()}`}>
                    {s}
                  </ToggleGroupItem>
                ))}
              </ToggleGroup>
              <p className="text-[11px] text-muted-foreground/70 leading-snug">
                Higher surfaces more partial and themed matches; lower keeps only the surest.
              </p>
            </div>

            {/* Transcript window */}
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Transcript Window (last words searched)</Label>
              <ToggleGroup
                type="single"
                value={String(settings.windowSize)}
                onValueChange={(v) => v && update("windowSize", Number(v))}
                className="grid grid-cols-3 gap-1"
              >
                {[20, 30, 40].map((w) => (
                  <ToggleGroupItem key={w} value={String(w)} className="text-xs h-8 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground" data-testid={`window-${w}`}>
                    {w} words
                  </ToggleGroupItem>
                ))}
              </ToggleGroup>
            </div>

            {/* Trigger Mode */}
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-0.5">
                <Label htmlFor="trigger-mode" className="text-sm">Scripture Trigger Mode</Label>
                <p className="text-[11px] text-muted-foreground/70 leading-snug">
                  Search harder after &ldquo;the Bible says,&rdquo; &ldquo;God says,&rdquo; &ldquo;it is written.&rdquo;
                </p>
              </div>
              <Switch id="trigger-mode" checked={settings.triggerMode} onCheckedChange={(c) => update("triggerMode", c)} data-testid="switch-trigger-mode" />
            </div>

            {/* Voice Coach Mode */}
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-0.5">
                <Label htmlFor="voice-coach" className="text-sm">Voice Coach Companion</Label>
                <p className="text-[11px] text-muted-foreground/70 leading-snug">
                  Recognize teaching, prayer, and exhortation patterns and lean in.
                </p>
              </div>
              <Switch id="voice-coach" checked={settings.voiceCoachMode} onCheckedChange={(c) => update("voiceCoachMode", c)} data-testid="switch-voice-coach" />
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Active detection indicators */}
        {(activeTrigger || activeContext) && status === 'Listening' && !detectionPaused && (
          <div className="flex flex-wrap gap-2">
            {activeTrigger && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full bg-primary/10 text-primary border border-primary/20" data-testid="indicator-trigger">
                <Quote className="h-3 w-3" />
                Trigger: &ldquo;{activeTrigger}&rdquo;
              </span>
            )}
            {activeContext && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-200" data-testid="indicator-context">
                <Sparkles className="h-3 w-3" />
                {activeContext}
              </span>
            )}
          </div>
        )}

        <div className="flex-1 flex flex-col gap-2 min-h-0">
          <div className="text-sm font-medium text-muted-foreground flex justify-between">
            Transcript
            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={clearTranscript} data-testid="button-clear-transcript">Clear</Button>
          </div>
          <div className="flex-1 min-h-32 overflow-auto rounded-lg border border-border/50 bg-background p-4 text-base leading-relaxed font-serif relative">
            <span className="text-foreground/80">{finalText}</span>
            <span className="text-foreground/40 italic"> {interimText}</span>
            {status === 'Listening' && !finalText && !interimText && (
              <span className="text-muted-foreground/30 absolute inset-0 flex items-center justify-center italic">Waiting for speech...</span>
            )}
          </div>
        </div>
      </div>

      {/* RIGHT: Scripture Feed */}
      <div className="flex-1 flex flex-col p-6 gap-4 overflow-hidden bg-background">
        <div className="flex items-center justify-between shrink-0">
          <h2 className="text-2xl font-serif font-bold text-primary flex items-center gap-2">
            Scripture Feed
            {detectionPaused && <span className="text-xs font-sans bg-muted text-muted-foreground px-2 py-0.5 rounded-full">Detection Paused</span>}
          </h2>
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-muted/50 rounded-lg p-1 border border-border/50">
              <Button variant="ghost" size="sm" className={`h-7 text-xs px-2 ${translation === 'KJV' ? 'bg-background shadow-sm' : ''}`} onClick={() => setTranslation('KJV')}>KJV</Button>
              <Button variant="ghost" size="sm" className={`h-7 text-xs px-2 ${translation === 'NIV' ? 'bg-background shadow-sm' : ''}`} onClick={() => { setTranslation('NIV'); toast({title: "NIV Support", description: NIV_PLACEHOLDER_NOTICE}); }}>NIV</Button>
            </div>
            {feed.length > 0 && (
              <Button variant="outline" size="sm" onClick={() => setMinistryView(true)} className="gap-2" data-testid="button-open-ministry-view">
                <Maximize2 className="h-4 w-4" />
                Ministry View
              </Button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-auto pr-4 space-y-4" ref={scrollRef}>
          {feed.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground/40 space-y-4">
              <BookOpenIcon className="h-16 w-16 opacity-20" />
              <p className="text-lg font-serif">Awaiting the Word...</p>
              <p className="text-sm font-sans max-w-sm text-center">As you speak, Minister will listen for Scripture references and partial verses to display here.</p>
            </div>
          ) : (
            feed.map((result, i) => {
              const v = result.verse;
              const ref = `${v.book} ${v.chapter}:${v.verse}`;
              const isFav = favorites.some(f => f.verse.book === v.book && f.verse.chapter === v.chapter && f.verse.verse === v.verse);
              const isTop = i === 0;

              return (
                <Card key={`${ref}-${i}`} className={`overflow-hidden border-border/50 transition-colors animate-in fade-in slide-in-from-top-4 ${isTop ? 'bg-primary/5 border-primary/20 shadow-sm' : 'bg-card/40 opacity-80'}`} data-testid={`feed-card-${i}`}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start gap-4 mb-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className={`font-serif font-bold ${isTop ? 'text-2xl text-primary' : 'text-xl text-foreground/80'}`}>{ref}</h3>
                          <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-primary/10 text-primary">{v.translation}</span>
                          <MatchBadge matchType={result.matchType} />
                          {isTop && <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-green-500/10 text-green-700 dark:text-green-400">Current Match</span>}
                        </div>
                        {result.matchReason && <p className="text-xs text-muted-foreground italic">{result.matchReason}</p>}
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => copyToClipboard(`${ref} ${v.translation} - ${v.text}`)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className={`h-8 w-8 ${isFav ? 'text-primary' : 'text-muted-foreground'}`} onClick={() => isFav ? null : addFavorite(v, "live")} disabled={isFav}>
                          {isFav ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                    <p className={`font-serif leading-relaxed ${isTop ? 'text-xl md:text-2xl text-foreground' : 'text-lg text-foreground/80'}`}>{v.text}</p>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {feed.length > 0 && (
          <div className="pt-2 border-t border-border/50 flex justify-end">
            <Button variant="ghost" size="sm" className="text-muted-foreground gap-2" onClick={clearFeed} data-testid="button-clear-feed">
              <Trash2 className="h-4 w-4" />
              Clear Feed
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function BookOpenIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  );
}
