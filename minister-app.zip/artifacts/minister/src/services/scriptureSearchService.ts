import Fuse, { type IFuseOptions } from "fuse.js";
import kjvData from "@/data/kjv.json";

export interface Verse {
  book: string;
  chapter: number;
  verse: number;
  text: string;
  translation: string;
}

/**
 * Human-readable confidence tier for a result, shown as a badge in the UI.
 *   Exact Match    — verbatim phrase / curated known phrase.
 *   Strong Match   — high lexical + fuzzy agreement.
 *   Possible Match — partial agreement worth surfacing.
 *   Theme Match    — only conceptual/keyword overlap.
 */
export type MatchType =
  | "Exact Match"
  | "Strong Match"
  | "Possible Match"
  | "Theme Match";

export type Sensitivity = "Low" | "Medium" | "High";

export interface SearchResult {
  verse: Verse;
  score: number; // confidence 0-100%
  matchType: MatchType;
  matchReason?: string;
}

export interface SearchOptions {
  /** Controls how permissive results are. Higher = more (lower score floor). */
  sensitivity?: Sensitivity;
  /** Explicit minimum score floor; overrides `sensitivity` when provided. */
  minScore?: number;
  /** Max number of results to return (default 5). */
  limit?: number;
}

// Minimum confidence a result must reach to be returned, per sensitivity level.
// Low = only the surest matches; High = surface partial/theme matches too.
const SENSITIVITY_FLOOR: Record<Sensitivity, number> = {
  Low: 74,
  Medium: 58,
  High: 44,
};

function classifyMatch(score: number, exact: boolean): MatchType {
  if (exact || score >= 90) return "Exact Match";
  if (score >= 72) return "Strong Match";
  if (score >= 55) return "Possible Match";
  return "Theme Match";
}

/**
 * Scripture search engine.
 *
 * Hybrid lexical matcher combining three signals so it can find verses from
 * partial, imperfect, or slightly misquoted phrases:
 *
 *   1. Curated known-phrase index   — guarantees correct results for the
 *      well-known phrases ministers reach for most (e.g. "be anxious for
 *      nothing", "no weapon formed"), including modern paraphrases whose exact
 *      wording is NOT in the KJV ("anxious" -> KJV "careful", "hidden" -> "hid").
 *   2. Fuse.js fuzzy matching       — great for contiguous, near-exact phrases.
 *   3. IDF-weighted token overlap   — great for distinctive-word misquotes,
 *      where rare words (e.g. "weapon", "formed") should outweigh common ones.
 *
 * Priority: exact/known phrase matches first, then fuzzy matches, then looser
 * concept/token matches.
 *
 * PERFORMANCE: tokenization, the document-frequency table, and an inverted index
 * (token -> verse ids) are all computed ONCE at module load. A query first
 * narrows to the verses that share its tokens (via the inverted index), caps to
 * the top candidates by IDF, then runs Fuse fuzzy ranking over ONLY that small
 * candidate set — never the full 31k-verse corpus per keystroke. This keeps a
 * search at ~15ms instead of ~1s, so live transcription stays responsive.
 *
 * ARCHITECTURE NOTE (future): For true conceptual/thematic recall (matching by
 * meaning rather than wording), add a semantic search layer using sentence
 * embeddings — precompute an embedding per verse, embed the query, and rank by
 * cosine similarity. That would resolve paraphrases without a curated list and
 * could be blended into the combined score below. See bibleApiService.ts.
 */

const STOP_WORDS = new Set(
  "a an the and or but of to in on at for with is are was were be been being this that these those thou thee thy thine ye you your unto shall will would should can could may might my his her him them they we us our it its as so by from out up down not no".split(
    " ",
  ),
);

function tokenize(s: string): string[] {
  return s
    .toLowerCase()
    .replace(/[^a-z\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 3);
}

const verses = kjvData as Verse[];

// --- Precomputed indexes (built once at module load) ---

// Per-verse unique token sets, document frequency, and an inverted index so a
// query only touches verses that contain its tokens.
const verseTokenSets: Set<string>[] = new Array(verses.length);
const docFreq = new Map<string, number>();
const invertedIndex = new Map<string, number[]>();

for (let i = 0; i < verses.length; i++) {
  const tokens = new Set(tokenize(verses[i].text));
  verseTokenSets[i] = tokens;
  for (const w of tokens) {
    docFreq.set(w, (docFreq.get(w) || 0) + 1);
    let postings = invertedIndex.get(w);
    if (!postings) {
      postings = [];
      invertedIndex.set(w, postings);
    }
    postings.push(i);
  }
}

const totalDocs = verses.length;
const idfCache = new Map<string, number>();
function idf(word: string): number {
  let v = idfCache.get(word);
  if (v === undefined) {
    v = Math.log(1 + totalDocs / ((docFreq.get(word) || 0) + 1));
    idfCache.set(word, v);
  }
  return v;
}

const refOf = (v: Verse) => `${v.book} ${v.chapter}:${v.verse}`;
const refToIndex = new Map<string, number>();
for (let i = 0; i < verses.length; i++) refToIndex.set(refOf(verses[i]), i);

// Fuse config. A scoped Fuse is built per query over only the candidate verses
// (see search()), so this is shared config rather than a corpus-wide index.
const fuseOptions: IFuseOptions<Verse> = {
  includeScore: true,
  threshold: 0.45,
  ignoreLocation: true,
  minMatchCharLength: 3,
  keys: ["text"],
};

// Cap how many IDF candidates get fuzzy-ranked, keeping per-query work bounded.
const MAX_FUZZY_CANDIDATES = 400;

// Trigger phrases stripped from the start of a query before searching.
// Ordered longest-first so the most specific trigger matches.
export const triggerPhrases = [
  "the word of god says",
  "god says",
  "the bible says",
  "scripture says",
  "the word says",
  "it is written",
  "jesus said",
  "paul says",
  "david said",
  "the lord says",
  "in the word",
];

/**
 * Scripture Trigger Mode: find a quotation cue ("the Bible says", "it is
 * written", ...) ANYWHERE in the spoken text, not just at the start. When one is
 * present the speaker is about to quote Scripture, so the caller searches more
 * aggressively. Returns the matched cue, or null.
 */
export function detectTrigger(text: string): string | null {
  const lower = text.toLowerCase();
  for (const phrase of triggerPhrases) {
    if (lower.includes(phrase)) return phrase;
  }
  return null;
}

/**
 * Voice Coach Companion Mode: recognize the kind of spoken ministry happening so
 * the app can lean in while someone is actively teaching, praying, or
 * exhorting. Pattern-based (not lexical Scripture matching). Returns a context
 * label, or null when ordinary conversation is detected.
 */
export type SpeechContext = "Preaching" | "Teaching" | "Prayer" | "Exhortation";

const SPEECH_CONTEXT_PATTERNS: { context: SpeechContext; pattern: RegExp }[] = [
  {
    context: "Prayer",
    pattern:
      /\b(let us pray|let's pray|father god|heavenly father|dear lord|in jesus(?:'|')?s? name|we thank you lord|we pray|hallelujah|hear our prayer)\b/i,
  },
  {
    context: "Teaching",
    pattern:
      /\b(turn (?:with me )?to|open your bible|let me teach|the lesson here|point number|first(?:ly)?,|second(?:ly)?,|notice (?:here|that)|class|study)\b/i,
  },
  {
    context: "Exhortation",
    pattern:
      /\b(i (?:want to )?encourage you|be strong|do not (?:be afraid|fear)|don'?t give up|press on|stand firm|i declare|receive this|take heart|hold fast)\b/i,
  },
  {
    context: "Preaching",
    pattern:
      /\b(church|saints|brothers and sisters|beloved|praise (?:god|the lord)|glory to god|can i get an amen|somebody say amen|let the church say)\b/i,
  },
];

export function detectSpeechContext(text: string): SpeechContext | null {
  for (const { context, pattern } of SPEECH_CONTEXT_PATTERNS) {
    if (pattern.test(text)) return context;
  }
  return null;
}

// Curated phrases (including common modern paraphrases) -> canonical reference.
// These are the phrases believers most often recall while speaking, and they
// guarantee the right verse surfaces even when the exact KJV wording differs.
interface KnownPhrase {
  phrases: string[];
  ref: string;
}
const knownPhrases: KnownPhrase[] = [
  {
    phrases: [
      "seek and ye shall find",
      "seek and you shall find",
      "knock and the door",
      "knock and it shall be opened",
      "ask and it shall be given",
    ],
    ref: "Matthew 7:7",
  },
  { phrases: ["no weapon formed", "no weapon formed against"], ref: "Isaiah 54:17" },
  {
    phrases: [
      "life and death are in the power",
      "death and life are in the power",
      "power of the tongue",
    ],
    ref: "Proverbs 18:21",
  },
  {
    phrases: ["all things work together", "all things work together for good"],
    ref: "Romans 8:28",
  },
  {
    phrases: ["be anxious for nothing", "do not be anxious", "be careful for nothing"],
    ref: "Philippians 4:6",
  },
  { phrases: ["train up a child"], ref: "Proverbs 22:6" },
  {
    phrases: ["the joy of the lord", "joy of the lord is my strength"],
    ref: "Nehemiah 8:10",
  },
  {
    phrases: ["i can do all things", "i can do all things through christ"],
    ref: "Philippians 4:13",
  },
  { phrases: ["my grace is sufficient"], ref: "2 Corinthians 12:9" },
  {
    phrases: ["perfect love casts out fear", "perfect love casteth out fear"],
    ref: "1 John 4:18",
  },
  {
    phrases: ["hidden in my heart", "hid in my heart", "thy word have i hid"],
    ref: "Psalms 119:11",
  },
  { phrases: ["faith comes by hearing", "faith cometh by hearing"], ref: "Romans 10:17" },
  { phrases: ["be still and know"], ref: "Psalms 46:10" },
];

/**
 * Strength that `query` matches a known `phrase`:
 *   1.0 — the phrase appears verbatim as a substring of the query.
 *   0.9 — every significant (non-stopword) token of the phrase appears in the
 *         query IN ORDER (an ordered subsequence). This catches paraphrases and
 *         filler words while rejecting reordered coincidental overlaps (e.g.
 *         "I know still waters" must NOT match "be still and know").
 *   0   — otherwise.
 */
function phraseMatchStrength(query: string, phrase: string): number {
  if (query.includes(phrase)) return 1;
  const phraseTokens = tokenize(phrase).filter((w) => !STOP_WORDS.has(w));
  if (!phraseTokens.length) return 0;
  const queryTokens = tokenize(query);
  let pi = 0;
  for (let qi = 0; qi < queryTokens.length && pi < phraseTokens.length; qi++) {
    if (queryTokens[qi] === phraseTokens[pi]) pi++;
  }
  return pi === phraseTokens.length ? 0.9 : 0;
}

export class ScriptureSearchService {
  /**
   * Strip a leading trigger phrase ("God says", "The Bible says", ...) from the
   * raw spoken text and return both the cleaned query and which trigger matched.
   */
  extractQuery(raw: string): { query: string; trigger: string | null } {
    let cleaned = raw.toLowerCase().trim();
    let trigger: string | null = null;
    for (const phrase of triggerPhrases) {
      if (cleaned.startsWith(phrase)) {
        cleaned = cleaned.replace(phrase, "").trim();
        trigger = phrase;
        break;
      }
    }
    return { query: cleaned, trigger };
  }

  search(rawQuery: string, options: SearchOptions = {}): SearchResult[] {
    const { query, trigger } = this.extractQuery(rawQuery);
    if (!query || query.length < 4) return [];

    const floor =
      options.minScore ?? SENSITIVITY_FLOOR[options.sensitivity ?? "Medium"];
    const limit = options.limit ?? 5;

    const results: {
      ref: string;
      score: number;
      reason: string;
      exact: boolean;
    }[] = [];
    const used = new Set<string>();

    // 1. Curated known-phrase matches (highest priority, scores 90-99).
    for (const known of knownPhrases) {
      let best = 0;
      let matched = "";
      for (const p of known.phrases) {
        const strength = phraseMatchStrength(query, p);
        if (strength > best) {
          best = strength;
          matched = p;
        }
      }
      if (best > 0 && refToIndex.has(known.ref)) {
        results.push({
          ref: known.ref,
          score: Math.round(90 + best * 9),
          reason: `matched phrase: ${matched}`,
          exact: best >= 1,
        });
        used.add(known.ref);
      }
    }

    // 2 + 3. Hybrid Fuse + IDF token scoring (capped at 89 so a curated hit
    // always outranks it). Candidates come from the inverted index (verses that
    // share query tokens) plus Fuse's fuzzy top results — never a full scan.
    const queryTokens = [...new Set(tokenize(query).filter((w) => !STOP_WORDS.has(w)))];
    const maxIdf = queryTokens.reduce((s, w) => s + idf(w), 0) || 1;

    // IDF score accumulation over inverted-index postings only. We also count
    // how many distinct query tokens each verse contains, so partial phrases
    // (where most-but-not-all words match) get a token-coverage boost below.
    const idfScore = new Map<number, number>();
    const coverage = new Map<number, number>();
    for (const w of queryTokens) {
      const postings = invertedIndex.get(w);
      if (!postings) continue;
      const wIdf = idf(w);
      for (const vi of postings) {
        idfScore.set(vi, (idfScore.get(vi) || 0) + wIdf);
        coverage.set(vi, (coverage.get(vi) || 0) + 1);
      }
    }

    // Keep only the strongest IDF candidates, then fuzzy-rank just those with a
    // scoped Fuse index (cheap — a few hundred verses, not the full corpus).
    const ranked = [...idfScore.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, MAX_FUZZY_CANDIDATES);

    const fuseScore = new Map<number, number>();
    if (ranked.length) {
      const candidateVerses = ranked.map(([vi]) => verses[vi]);
      const scopedFuse = new Fuse(candidateVerses, fuseOptions);
      for (const r of scopedFuse.search(query).slice(0, 80)) {
        const vi = refToIndex.get(refOf(r.item));
        if (vi !== undefined) fuseScore.set(vi, 1 - (r.score || 0));
      }
    }

    const engineResults: {
      ref: string;
      score: number;
      reason: string;
      exact: boolean;
    }[] = [];
    for (const [vi, rawIdf] of ranked) {
      const v = verses[vi];
      const i = rawIdf / maxIdf;
      const f = fuseScore.get(vi) || 0;
      let combined = 0.5 * i + 0.5 * f;
      // Token-coverage boost: reward verses that contain a larger share of the
      // spoken query's distinctive words, so partial phrases still rank well.
      if (queryTokens.length) {
        combined += 0.15 * ((coverage.get(vi) || 0) / queryTokens.length);
      }
      const isSubstring = v.text.toLowerCase().includes(query);
      if (isSubstring) combined += 0.4;
      engineResults.push({
        ref: refOf(v),
        score: Math.min(89, Math.round(combined * 100)),
        reason: isSubstring ? `matched phrase: ${query}` : `related to: ${query}`,
        exact: isSubstring,
      });
    }
    engineResults.sort((a, b) => b.score - a.score);
    for (const e of engineResults.slice(0, 10)) {
      if (!used.has(e.ref)) {
        results.push(e);
        used.add(e.ref);
      }
    }

    results.sort((a, b) => b.score - a.score);

    return results
      .filter((r) => r.score >= floor)
      .slice(0, limit)
      .map((r) => {
        const verse = verses[refToIndex.get(r.ref)!];
        const reason = trigger ? `${r.reason} (after "${trigger}")` : r.reason;
        return {
          verse,
          score: r.score,
          matchType: classifyMatch(r.score, r.exact),
          matchReason: reason,
        };
      });
  }
}

export const scriptureSearchService = new ScriptureSearchService();
