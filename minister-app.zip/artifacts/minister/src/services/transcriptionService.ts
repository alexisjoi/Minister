export interface TranscriptionProvider {
  start(): void;
  stop(): void;
  onInterimResult(callback: (text: string) => void): void;
  onFinalResult(callback: (text: string) => void): void;
  onStatusChange(callback: (status: 'Not Listening' | 'Requesting Permission' | 'Listening' | 'Paused' | 'Error') => void): void;
  onError(callback: (error: string) => void): void;
}

export class WebSpeechTranscriptionProvider implements TranscriptionProvider {
  private recognition: any = null;
  private isListening = false;
  private interimCallback: ((text: string) => void) | null = null;
  private finalCallback: ((text: string) => void) | null = null;
  private statusCallback: ((status: 'Not Listening' | 'Requesting Permission' | 'Listening' | 'Paused' | 'Error') => void) | null = null;
  private errorCallback: ((error: string) => void) | null = null;
  
  constructor() {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      
      this.recognition.onstart = () => {
        this.isListening = true;
        this.statusCallback?.('Listening');
      };
      
      this.recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          this.statusCallback?.('Error');
          this.errorCallback?.('Microphone permission denied.');
        } else {
          this.statusCallback?.('Error');
          this.errorCallback?.(event.error);
        }
      };
      
      this.recognition.onend = () => {
        if (this.isListening) {
          // Auto restart if disconnected unexpectedly while supposed to be listening
          try {
            this.recognition.start();
          } catch(e) {
            this.isListening = false;
            this.statusCallback?.('Not Listening');
          }
        } else {
          this.statusCallback?.('Not Listening');
        }
      };
      
      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        
        if (interimTranscript && this.interimCallback) this.interimCallback(interimTranscript);
        if (finalTranscript && this.finalCallback) this.finalCallback(finalTranscript);
      };
    }
  }
  
  start() {
    if (!this.recognition) {
      this.statusCallback?.('Error');
      this.errorCallback?.('Web Speech API is not supported in this browser.');
      return;
    }
    this.statusCallback?.('Requesting Permission');
    try {
      this.recognition.start();
    } catch (e: any) {
      this.statusCallback?.('Error');
      this.errorCallback?.(e.message);
    }
  }
  
  stop() {
    this.isListening = false;
    if (this.recognition) {
      this.recognition.stop();
    }
    this.statusCallback?.('Not Listening');
  }
  
  onInterimResult(callback: (text: string) => void) {
    this.interimCallback = callback;
  }
  
  onFinalResult(callback: (text: string) => void) {
    this.finalCallback = callback;
  }
  
  onStatusChange(callback: (status: 'Not Listening' | 'Requesting Permission' | 'Listening' | 'Paused' | 'Error') => void) {
    this.statusCallback = callback;
  }
  
  onError(callback: (error: string) => void) {
    this.errorCallback = callback;
  }
}

// ---------------------------------------------------------------------------
// DEVELOPER NOTE — Replacing browser transcription with the OpenAI Realtime API
// ---------------------------------------------------------------------------
//
// The whole app talks to transcription through the `TranscriptionProvider`
// interface above. Nothing else (Live page, search engine) knows or cares that
// the current implementation is the browser's Web Speech API. That is the seam:
// to upgrade, write a second class that implements the SAME interface and swap
// which one `Live` instantiates — no other code needs to change.
//
// Why upgrade later:
//   - Web Speech API is browser-dependent (best in Chrome), stops on silence,
//     and gives no control over the model, vocabulary, or latency.
//   - OpenAI's Realtime API streams audio over WebRTC/WebSocket and returns
//     low-latency interim + final transcripts with far better accuracy on
//     proper nouns and Scripture phrasing — and opens the door to true
//     conceptual/semantic verse detection and spoken commands
//     ("Minister, save that Scripture").
//
// Implementation sketch — class OpenAIRealtimeTranscriptionProvider:
//   1. SECURITY: never ship an OpenAI API key to the browser. Add a tiny
//      backend route (e.g. in the existing api-server artifact) that mints a
//      short-lived Realtime *ephemeral* client token and returns it to the
//      client. The browser uses only that ephemeral token.
//        - This MVP is currently frontend-only; adding this provider is the
//          point where Minister gains a backend.
//        - Store OPENAI_API_KEY as a server-side secret (see the
//          environment-secrets skill), never in VITE_* vars (those are public).
//   2. CAPTURE: getUserMedia({ audio: true }) — keep the existing rule that the
//      mic is never opened until the user explicitly starts live listening.
//   3. CONNECT: open a WebRTC peer connection (or WebSocket) to the Realtime
//      endpoint using the ephemeral token; attach the mic track.
//   4. EVENTS: map Realtime transcription deltas -> onInterimResult(text) and
//      completed segments -> onFinalResult(text); map connection lifecycle ->
//      onStatusChange(...) and failures -> onError(...). The Live page already
//      builds its rolling transcript window from these callbacks, so detection,
//      Trigger Mode, and Voice Coach Mode keep working unchanged.
//   5. STOP: stop() must close the peer connection AND stop every mic track
//      (track.stop()) so the OS mic indicator turns off.
//
// Swap point: in src/pages/live.tsx, replace
//   new WebSpeechTranscriptionProvider()
// with
//   new OpenAIRealtimeTranscriptionProvider()
// (ideally behind a setting or feature flag so users can fall back offline).
//
// export class OpenAIRealtimeTranscriptionProvider implements TranscriptionProvider { ... }
