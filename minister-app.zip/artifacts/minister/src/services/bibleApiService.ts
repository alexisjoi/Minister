// Thin abstraction for future remote Bible sources
export interface BibleApiService {
  search(query: string, translation: string): Promise<any>;
}

export class RemoteBibleApiService implements BibleApiService {
  async search(query: string, translation: string): Promise<any> {
    // TODO: implement remote API calls
    return [];
  }
}

export const bibleApiService = new RemoteBibleApiService();
