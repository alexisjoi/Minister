export const PRIVACY_NOTICE_LIVE = "Minister only listens when you choose to start live listening. Your microphone is never accessed until you give permission.";

export const CONSENT_NOTICE = "By starting Minister Live, you allow this browser session to access your microphone for live transcription and Scripture lookup. Minister is designed to support Scripture remembrance while speaking. Please do not use live listening in private conversations without the knowledge and consent of those present.";

export const FOOTER_LEGAL = "Minister is a Scripture remembrance and study support tool. It does not replace prayer, study, pastoral counsel, spiritual discernment, or the work of the Holy Spirit. Scripture results should be reviewed in context.";

export const COPYRIGHT_NOTICE = "KJV text may be used locally in the MVP where legally permitted. NIV and many modern Bible translations are copyrighted and require permission or licensed API access. Minister will support modern translations only through proper licensing or authorized Bible APIs.";

export const NIV_PLACEHOLDER_NOTICE = "NIV Scripture support requires licensed access. Do not upload, store, or distribute the full NIV text in this app without permission from the rights holder or access through an authorized Bible API.";
